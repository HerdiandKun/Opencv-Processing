# Opencv-Processing

Merupakan kumpulan fungsi untuk pemrosesan gambar dengan opencv dan c++<br/>

Fungsi yang saat ini tersedia<br/>
<b>Thresholding<br/>
Negative Image<br/>
Contras Streching<br/>
Croping with two image<br/></b>

